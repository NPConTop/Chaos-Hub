## Vii Userbot
```
apt update && apt upgrade -y
```
```
git clone https://github.com/userguthub/namarepo
```
```
cd namarepo && screen -S namarepo
```
```
apt install ffmpeg -y
```
```
bash installnode.sh
```
```
apt install python3.10-venv
```
```
python3 -m venv venv && source venv/bin/activate
```
```
pip3 install -r requirements.txt
```
```
cp sample.env .env && nano .env
```
```
screen -S namarepo
```
```
python3 -m PyroUbot
```
```
---------- Menghidupan jika ubot mati -------------
```
```
cd namarepo && screen -S namarepo
```
```
python3 -m venv venv && source venv/bin/activate
```
```
screen -S namarepo && python3 -m PyroUbot
```
