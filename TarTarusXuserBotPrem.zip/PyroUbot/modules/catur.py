__MODULE__ = "catur"
__HELP__ = """
<b>⦪࿈ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴄᴀᴛᴜʀ ࿈⦫<b>

<blockquote><b>⎆ perintah :
ᚗ <code>{0}catur</code>
⊶ untuk memunculkan game catur</b></blockquote>
"""
